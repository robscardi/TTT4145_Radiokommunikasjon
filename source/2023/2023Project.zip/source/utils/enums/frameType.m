classdef frameType < Simulink.IntEnumType
    %FRAMETYPE Summary of this class goes here
    %   Detailed explanation goes here
    enumeration
    INVALID(0)
    END(1)
    START(2)
    BERT(4)
    LSF(8)
    PACKET(16)
    STREAM(32)
    end
end

