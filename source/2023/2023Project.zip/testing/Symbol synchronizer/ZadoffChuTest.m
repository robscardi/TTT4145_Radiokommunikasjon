close all
clearvars -except Param

